(() => {
  "use strict";

  const isNative = !!window.webkit?.messageHandlers?.macwipeBridge;

  const categories = isNative
    ? Object.fromEntries(
        Object.entries(MacwipeData).map(([key, category]) => [
          key,
          {
            title: category.title,
            description: "Actual files scanned from system paths",
            items: [],
          },
        ]),
      )
    : MacwipeData;

  const { formatMB, createChat } = MacwipeUI;
  let allItems = Object.values(categories).flatMap(
    (category) => category.items || [],
  );
  const itemById = new Map(allItems.map((item) => [item.id, item]));
  const selected = new Set();
  const cachedRows = new Map();
  const checkboxById = new Map();
  let currentCategory = null;
  let selectedMB = 0;

  // Resolve persistent DOM nodes once; event handlers reuse these references.
  const tableBody = document.querySelector("#item-table-body");
  const fileList = document.querySelector("#file-list");
  const navButtons = document.querySelectorAll("[data-category]");
  const heading = document.querySelector("#dashboard-heading");
  const description = document.querySelector("#category-description");
  const caption = document.querySelector("#list-caption");
  const selectionStatus = document.querySelector("#selection-status");
  const selectAllButton = document.querySelector("#btn-select-all");
  const reviewButton = document.querySelector("#btn-review-selected");
  const previewButton = document.querySelector("#btn-preview-scan");
  const reviewDialog = document.querySelector("#review-dialog");
  const reviewList = document.querySelector("#review-items-list");
  const reviewTotal = document.querySelector("#review-total-size");
  const previewNote = document.querySelector(".preview-note");
  const reviewIntro = reviewDialog.querySelector(".dialog-body > p");
  const reviewNotice = document.querySelector("#review-notice");
  const confirmButton = document.querySelector("#review-simulate-btn");
  const openDetails = createChat(document.querySelector("#details-dialog"));

  function updateSelection() {
    const count = selected.size;
    const summary = `Selected: ${count} ${count === 1 ? "item" : "items"} · ${formatMB(selectedMB)}`;
    if (selectionStatus.textContent !== summary)
      selectionStatus.textContent = summary;
    reviewButton.disabled = count === 0;
    const cat = categories[currentCategory];
    const selectableItems = (cat && cat.items ? cat.items : []).filter(
      (item) => item.canClean !== false,
    );
    selectAllButton.disabled = selectableItems.length === 0;
    const allChecked =
      selectableItems.length > 0 &&
      selectableItems.every((item) => selected.has(item.id));
    const label = allChecked ? "Deselect all" : "Select all";
    if (selectAllButton.textContent !== label)
      selectAllButton.textContent = label;
  }

  function setSelected(item, checked) {
    if (item.canClean === false) return;
    if (selected.has(item.id) !== checked) {
      if (checked) selected.add(item.id);
      else selected.delete(item.id);
      selectedMB += checked ? item.mb : -item.mb;
    }
    const checkbox = checkboxById.get(item.id);
    if (checkbox && checkbox.checked !== checked) checkbox.checked = checked;
  }

  function refreshSelection() {
    if (!categories[currentCategory] || !categories[currentCategory].items)
      return;
    categories[currentCategory].items.forEach((item) => {
      setSelected(item, selected.has(item.id));
    });
    updateSelection();
  }

  function createRow(item) {
    const row = document.createElement("tr");
    const selectCell = document.createElement("td");
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.disabled = item.canClean === false;
    checkbox.dataset.item = item.id;
    if (isNative) {
      checkbox.dataset.category = item.category;
      if (item.path) checkbox.dataset.path = item.path;
    }
    checkbox.setAttribute("aria-label", `Select ${item.name}`);
    checkboxById.set(item.id, checkbox);
    selectCell.append(checkbox);

    const nameCell = document.createElement("td");
    nameCell.textContent = item.name;
    const infoCell = document.createElement("td");
    infoCell.textContent = item.info || formatMB(item.mb);
    const detailsCell = document.createElement("td");
    const detailsButton = document.createElement("button");
    detailsButton.type = "button";
    detailsButton.className = "question-row";
    detailsButton.dataset.details = item.id;
    detailsButton.textContent = "Details";
    detailsButton.setAttribute("aria-label", `Details about ${item.name}`);
    detailsButton.setAttribute("aria-haspopup", "dialog");
    detailsButton.setAttribute("aria-controls", "details-dialog");
    detailsCell.append(detailsButton);
    row.append(selectCell, nameCell, infoCell, detailsCell);
    return row;
  }

  function switchCategory(key) {
    if (key === currentCategory || !Object.hasOwn(categories, key)) return;
    currentCategory = key;
    const category = categories[key];
    document.title = `macwipe · ${category.title} · ${isNative ? "Native" : "Demo"}`;
    heading.textContent = category.title;
    description.textContent = category.description;
    caption.textContent = `${category.title} items`;
    navButtons.forEach((button) => {
      if (button.dataset.category === key)
        button.setAttribute("aria-current", "page");
      else button.removeAttribute("aria-current");
    });

    if (!cachedRows.has(key))
      cachedRows.set(key, (category.items || []).map(createRow));

    const fragment = document.createDocumentFragment();
    fragment.append(...cachedRows.get(key));
    if (isNative && !category.items.length) {
      const row = document.createElement("tr");
      const cell = document.createElement("td");
      cell.colSpan = 4;
      cell.textContent = "No accessible eligible items found.";
      row.append(cell);
      fragment.append(row);
    }
    tableBody.replaceChildren(fragment);
    tableBody.querySelectorAll("input[data-item]").forEach((checkbox) => {
      checkboxById.set(checkbox.dataset.item, checkbox);
    });
    refreshSelection();
  }

  function selectAll() {
    const cat = categories[currentCategory];
    const items = (cat && cat.items ? cat.items : []).filter(
      (item) => item.canClean !== false,
    );
    const checked = !items.every((item) => selected.has(item.id));
    items.forEach((item) => setSelected(item, checked));
    updateSelection();
  }

  function review() {
    if (!selected.size) return;
    if (isNative) {
      reviewIntro.textContent = "Selected files for cleanup:";
      reviewNotice.textContent =
        "Selected files will be moved to Trash. Applications and support folders may contain personal data. Removing startup files does not stop running services. Close affected apps and browsers first.";
      confirmButton.hidden = false;
      confirmButton.style.display = "";
      confirmButton.textContent = "Clean Selected";
    }
    const items = allItems.filter((item) => selected.has(item.id));
    const fragment = document.createDocumentFragment();
    items.forEach((item) => {
      const entry = document.createElement("li");
      entry.textContent = `${item.name} · ${item.info || formatMB(item.mb)}`;
      fragment.append(entry);
    });
    reviewList.replaceChildren(fragment);
    reviewTotal.textContent = formatMB(selectedMB);
    reviewDialog.showModal();
  }

  function scrollFiles(direction) {
    fileList.scrollBy({
      top: direction * fileList.clientHeight * 0.75,
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches
        ? "instant"
        : "smooth",
    });
  }

  const actions = {
    "scroll-up": () => scrollFiles(-1),
    "scroll-down": () => scrollFiles(1),
    preview: () => {
      if (isNative) {
        previewNote.textContent = "Scanning local files...";
        window.macwipeUI.scan();
      } else refreshSelection();
    },
    "select-all": selectAll,
    review,
    simulate: () => {
      if (isNative) {
        const grouped = new Map();
        selected.forEach((id) => {
          const item = itemById.get(id);
          if (!item) return;
          const catKey = item.category;
          if (!grouped.has(catKey)) grouped.set(catKey, []);
          grouped.get(catKey).push(item.path);
        });
        const selectedCategories = Array.from(grouped, ([id, paths]) => ({
          id,
          paths,
        }));
        if (window.macwipeUI.delete(selectedCategories) !== false)
          reviewDialog.close();
        return;
      }
      reviewDialog.close();
      selected.forEach((id) => setSelected(itemById.get(id), false));
      updateSelection();
      previewButton.focus();
    },
  };

  document.addEventListener("click", (event) => {
    const button = event.target.closest("button");
    if (!button || button.disabled) return;
    if (button.dataset.category) switchCategory(button.dataset.category);
    else if (button.dataset.details) {
      const item = itemById.get(button.dataset.details);
      if (item) openDetails(`Tell me about ${item.name}.`, item.details);
    } else if (Object.hasOwn(actions, button.dataset.action)) {
      actions[button.dataset.action]();
    }
  });

  tableBody.addEventListener("change", (event) => {
    const item = itemById.get(event.target.dataset.item);
    if (!item) return;
    setSelected(item, event.target.checked);
    updateSelection();
  });

  if (isNative) {
    document.querySelector(".demo-tag").textContent = "Native · System Scan";
    previewNote.textContent = "Scanning local files...";
    fileList.setAttribute("aria-label", "Local scanned files");
    document.querySelector(".dashboard > .status-strip").textContent =
      "macOS helper · Native · System Scan";

    const nativeUI = window.macwipeUI;
    const receiveScanData = nativeUI.receiveScanData;
    const onCleanupComplete = nativeUI.onCleanupComplete;

    nativeUI.receiveScanData = function (payload) {
      if (receiveScanData) receiveScanData.call(this, payload);

      for (const [key, category] of Object.entries(categories)) {
        category.items = (payload.categories[key]?.items || []).map((file) => ({
          id: file.id,
          category: file.category,
          path: file.path,
          name: file.name,
          mb: file.bytes / 1_000_000,
          info: file.formatted || formatMB(file.bytes / 1_000_000),
          details: `${file.path}. ${payload.sizeMeaning || ""}`,
          canClean: file.canClean === true,
        }));
      }
      // Storage and category tabs can share a file; review each ID only once.
      allItems = [
        ...new Map(
          Object.values(categories).flatMap((category) =>
            category.items.map((item) => [item.id, item]),
          ),
        ).values(),
      ];

      itemById.clear();
      allItems.forEach((item) => itemById.set(item.id, item));
      selected.clear();
      selectedMB = 0;
      cachedRows.clear();
      checkboxById.clear();
      const key = currentCategory;
      currentCategory = null;
      switchCategory(key || "storage");

      previewNote.textContent = "Scan complete. Review files before cleanup.";
      if (reviewDialog.open && !confirmButton.hidden) reviewDialog.close();
    };

    nativeUI.onCleanupComplete = function (freedMB, result = {}) {
      if (onCleanupComplete) onCleanupComplete.call(this, freedMB, result);
      reviewIntro.textContent = "Cleanup complete.";
      reviewList.replaceChildren();
      reviewTotal.textContent = formatMB(result.diskFreedMB ?? freedMB);
      reviewNotice.textContent = `Disk space freed: ${formatMB(result.diskFreedMB ?? freedMB)}.`;
      confirmButton.hidden = true;
      confirmButton.style.display = "none";
      if (!reviewDialog.open) reviewDialog.showModal();
      if (result.errors?.length)
        reviewNotice.textContent += ` ${result.errors.join(" ")}`;
      if (nativeUI.scan) nativeUI.scan();
    };
    window.addEventListener("macwipe:error", (event) => {
      previewNote.textContent = event.detail.message;
    });
  }

  switchCategory("storage");
  if (isNative && window.macwipeUI?.scan) window.macwipeUI.scan();
})();
